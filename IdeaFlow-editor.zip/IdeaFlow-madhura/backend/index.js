require("dotenv").config();

const express = require("express");
const openai = require("openai"); // Assuming you use OpenAI Node.js library
const bodyParser = require("body-parser");
const cors = require("cors");
const app = express();

app.use(cors());
app.use(express.json());
app.use(bodyParser.json());

// Load API key from environment variable
openai.apiKey = process.env.OPENAI_API_KEY;

// API endpoint to generate Mermaid code
app.post("/api/generate-mermaid", async (req, res) => {
  console.log(req.body);
  const { searchTerm } = req.body; // Extract search term from request body

  const options = {
    method: "POST",
    headers: {
      Authorization: `Bearer ${process.env.OPENAI_API_KEY}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      model: "gpt-3.5-turbo",
      messages: [
        {
          role: "user",
          content:
            "Generate a flowchart Mermaid code representing the following process: " +
            req.body.searchTerm,
        },
      ],
      max_tokens: 100,
    }),
  };
  try {
    const response = await fetch(
      "https://api.openai.com/v1/chat/completions",
      options
    );
    const data = await response.json();
    console.log(data);
    res.send(data);
  } catch (error) {
    console.log(error);
  }
});

// Start the server
app.listen(3000, () => console.log("Server listening on port 3000"));
