// import React from 'react'
import {Row, Col} from 'antd'
import GeneralShapes from '../components/GeneralShapes'
import FlowchartCanvas from '../components/FlowchartCanvas'

const Home = () => {
  return (
    <div>
      
    <Row
      gutter = {[32 , 32]}
      style={{
        // marginTop:'32px',

      }}

    >
      <Col
      xs ={16}
      sm ={16}
      xl = {8}
      style ={{
        height: '460px'
      }}
      >
        <GeneralShapes/>
      </Col>

      <Col
      xs ={24}
      sm ={24}
      xl = {16}
      style ={{
        height: '460px'
      }}
      >
        <FlowchartCanvas/>
    </Col>
    </Row>

    <Row gutter={[32, 32]}
    style={{
      marginTop:'32px'
    }}
    >
      
    </Row>
  </div>
  )
}

export default Home