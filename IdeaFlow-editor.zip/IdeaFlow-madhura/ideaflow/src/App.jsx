// import { useState } from 'react'
import './App.css'
 
// import {Card} from 'antd'
import Header from './components/Header'
import Home from './pages/home'

function App() {
  // const [count, setCount] = useState(0)

  return (
    <>
    
    <Header />
    <Home />

    </>
  )
}

export default App
