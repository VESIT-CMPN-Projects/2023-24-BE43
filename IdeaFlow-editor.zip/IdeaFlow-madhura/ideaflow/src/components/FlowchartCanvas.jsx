import React from 'react';
import { Card } from 'antd';
// import ReactMermaid from 'react-mermaid';

const FlowchartCanvas = () => {
  const flowchartCode = `
    graph LR
    A[Start] --> B{Conditional}
    B -->|Yes| C{Process}
    C -->|No| D[End]
  `;

  const svgStyle = {
    width: '100%',
    height: '100%',
    position: 'relative',
    zIndex: -1,
    backgroundColor:'#f0f5ff'
  };

  return (
    <Card
      
      style={{
        height: '100%',
        overflow: 'hidden',
        marginRight: '1rem',
        background: 'transparent',
        position: 'relative', // Add position relative for proper positioning of the absolute SVG
      }}
      headStyle={{ padding: '4px 8px' }}
      bodyStyle={{ padding: '0px' }}
    >
      <svg width="800" height="800" style={svgStyle}>
        <defs>
          <pattern id="grid" width="20" height="20" patternUnits="userSpaceOnUse">
            <rect width="20" height="20" fill="none" stroke="#d7d7d7" strokeWidth="1" />
            <rect width="1" height="20" fill="none" stroke="#d7d7d7" strokeWidth="2" strokeDasharray="5,5" />
            <rect width="20" height="1" fill="none" stroke="#d7d7d7" strokeWidth="2" strokeDasharray="5,5" />
          </pattern>
        </defs>
        <rect width="100%" height="100%" fill="url(#grid)" />
      </svg>

      {/* <ReactMermaid  flowchartCode={flowchartCode}/> */}
    </Card>
  );
};

export default FlowchartCanvas;
