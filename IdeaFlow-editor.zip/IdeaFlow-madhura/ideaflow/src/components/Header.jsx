import React, { useState, PureComponent } from 'react'
import{Layout, Space, Button, Popover} from "antd";
import {SaveOutlined, ExportOutlined} from '@ant-design/icons';

const Header = () => {


    const [open, setOpen] = useState(false);

    const handleOpenChange = (newOpen) => {
        setOpen(newOpen);
      };

  const headerStyles = {
      background : '#f0f5ff',
      margin:'1rem',
      display : "flex",
      flexDirection : "row",
      padding : "0 8px",
      position : "sticky",
      top : 0,
      zIndex : 999,
      justifyContent: "space-between",
      borderRadius:'6px'

  };

  const cont =(
        <div 
            style={{
                display:'flex',
                flexDirection: 'column',
                gap:'4px',
                width: '8rem'
            }}
        >
            <Button>JPG</Button>
            <Button>PNG</Button>
            <Button>JSON</Button>
        </div>
    );
    
  return (
    <>
    <Layout.Header
        style={headerStyles}    
    >
      <Space
        align ="center"
        size="middle"   
        style={{
            width:'100%',
            display: "flex",
            
        }}   
      >
        <h5 style ={{}}>IdeaFlow</h5>  
      </Space>

      <div
        style={{
            display:'flex',
            flexDirection: 'row',
            alignItems: 'center',
            justifyContent:'space-around',
        }}
      >
            <Button 
            style={{backgroundColor: '#535bf2', color:'white'}}
            >
                <SaveOutlined />
                Save
            </Button>
            
            <Popover
            content={cont}
            trigger="click"
            open={open}
            overlayInnerStyle={{padding:0}}
            overlayStyle ={{ zindex: 999 }}
            onOpenChange={handleOpenChange}
            >
            <Button 
            style={{backgroundColor: '#535bf2', color:'white', marginLeft:'10px'}}
            >
                <ExportOutlined />
                Export
            </Button>
            </Popover>
        </div>
        
    </Layout.Header>
    </>
  )
}

export default Header