// import React from 'react';
import { Card, Row, Col, Input, Button } from "antd";
import { useState } from "react";
// import { ReactFlowChart } from 'react-flowchart'; // Import the named export

const GeneralShapes = () => {
  const [searchTerm, setSearchTerm] = useState("");
  const [mermaidCode, setMermaidCode] = useState();

  const handleSearch = async () => {
    // Send search term to backend
    const response = await fetch("http://localhost:3000/api/generate-mermaid", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ searchTerm }),
    });

    const data = await response.json();
    console.log(data);
    setMermaidCode(data);

    // Update UI with generated Mermaid code (details in step 4)
  };

  return (
    <Card
      style={{
        height: "100%",
        marginLeft: "1rem",
        background: "#f0f5ff",
      }}
      headStyle={{ padding: "4px 8px" }}
      bodyStyle={{ padding: "24px 24px 0 24px" }}
      title={
        <div style={{ display: "flex", alignItems: "center", gap: "8px" }}>
          <p>General Shapes and Connectors</p>
        </div>
      }
    >
      <div style={{ display: "flex", flexDirection: "column" }}>
        <div style={{ display: "flex", alignItems: "center" }}>
          {/* Search box */}
          <Input.Search
            placeholder="Search for shapes or connectors (e.g., decision, process)"
            allowClear
            style={{ width: "100%", marginRight: "8px" }}
            onChange={(e) => setSearchTerm(e.target.value)}
            onSearch={handleSearch} // Trigger search on Enter or button click
          />
        </div>

        <div style={{ marginTop: "16px" }}>
          {mermaidCode && <p>{mermaidCode.choices[0].message.content}</p>}
          {/* {mermaidCode && ( // Render only if mermaidCode has a value
            <ReactFlowChart code={mermaidCode} /> // Pass code as prop
          )} */}
        </div>
      </div>
    </Card>
  );
};

export default GeneralShapes;
